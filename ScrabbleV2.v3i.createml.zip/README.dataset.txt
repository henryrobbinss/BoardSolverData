# ScrabbleV2 > 2024-10-08 8:57pm
https://universe.roboflow.com/projects-zidii/scrabblev2

Provided by a Roboflow user
License: MIT

