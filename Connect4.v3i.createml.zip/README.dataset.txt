# Connect4 > 2024-02-13 5:04pm
https://universe.roboflow.com/projects-zidii/connect4

Provided by a Roboflow user
License: CC BY 4.0

