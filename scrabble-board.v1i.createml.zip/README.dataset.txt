# scrabble-board > 2024-07-30 6:24pm
https://universe.roboflow.com/projects-zidii/scrabble-board

Provided by a Roboflow user
License: CC BY 4.0

